const char WEB_PAGE[] PROGMEM = R"=====(
<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
    <style>
        body { font-family: sans-serif; text-align: center; background: #1a1a2e; color: white; padding: 20px; }
        .card { background: #16213e; padding: 15px; border-radius: 15px; margin-bottom: 15px; border: 1px solid #0f3460; }
        .btn { width: 100%; padding: 12px; border-radius: 8px; border: none; cursor: pointer; font-size: 16px; font-weight: bold; margin: 5px 0; }
        .btn-toggle { background: #e94560; color: white; }
        .btn-sw { background: #0f3460; color: white; border: 1px solid #e94560; }
        input[type=range] { width: 100%; margin-top: 15px; }
        .reset-link { color: #555; font-size: 12px; text-decoration: none; margin-top: 20px; display: block; }
    </style>
</head>
<body>
    <h2>SENTRI Dashboard</h2>
    
    <div class="card">
        <h3>التحكم في LED (Pin 18)</h3>
        <button class="btn btn-toggle" onclick="fetch('/toggleLed').then(()=>location.reload())">تبديل الإضاءة</button>
    </div>

    <div class="card">
        <h3>شدة الإضاءة (Light)</h3>
        <input type="range" min="0" max="100" value="{{BRIGHT}}" onchange="fetch('/setLight?val=' + this.value).then(()=>location.reload())">
        <p>السطوع: {{BRIGHT}}%</p>
    </div>

    <div class="card">
        <h3>المقابس (Switches)</h3>
        <button class="btn btn-sw" onclick="fetch('/toggleSw1').then(()=>location.reload())">تبديل Switch 1</button>
        <button class="btn btn-sw" onclick="fetch('/toggleSw2').then(()=>location.reload())">تبديل Switch 2</button>
    </div>

    <a href="/reset" class="reset-link">إعادة ضبط إعدادات الواي فاي</a>
</body>
</html>
)=====";