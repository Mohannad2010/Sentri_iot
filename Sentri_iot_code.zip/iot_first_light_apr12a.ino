#include "arduino_secrets.h"
#include <WiFiManager.h>
#include "thingProperties.h"

// --- Pins Definitions | تعريف أطراف التوصيل ---
int LED_1 = 18;            // Room Light 1 | ضوء الغرفة الرئيسي
int POWER_1 = 16;          // Socket 1 | القابس الأول (إبريز 1)
int POWER_2 = 17;          // Socket 2 | القابس الثاني (إبريز 2)
int LIGHT_PIN = 27;        // PWM for LED Strip | شريط اللد
int WALL_SWITCH_PIN = 19;  // Physical Switch | مفتاح الحائط
int Led_2 = 22;            // Light 2 | ضوء 2
int Led_3 = 23;            // Light 3 | ضوء 3
int Sleep_switch = 2;      // Sleep Mode Switch | مفتاح وضع النوم
int Work_switch = 4;       // Work Mode Switch | مفتاح وضع العمل
int All_switch = 15;       // All Mode Switch (Previously X) | مفتاح تشغيل الكل

// --- State Variables | متغيرات الحالة ---
bool lastWallState, lastSleepState, lastWorkState, lastAllState;

const int channel = 0;
bool firstSyncDone = false; 
WiFiManager wm;

void setup() {
  Serial.begin(115200);
  
  pinMode(LED_1, OUTPUT);
  pinMode(Led_2, OUTPUT);
  pinMode(Led_3, OUTPUT);
  pinMode(POWER_1, OUTPUT);
  pinMode(POWER_2, OUTPUT);

  pinMode(WALL_SWITCH_PIN, INPUT_PULLUP);
  pinMode(Sleep_switch, INPUT_PULLUP);
  pinMode(Work_switch, INPUT_PULLUP);
  pinMode(All_switch, INPUT_PULLUP);

  lastWallState = digitalRead(WALL_SWITCH_PIN);
  lastSleepState = digitalRead(Sleep_switch);
  lastWorkState = digitalRead(Work_switch);
  lastAllState = digitalRead(All_switch);

  ledcSetup(channel, 5000, 8);
  ledcAttachPin(LIGHT_PIN, channel);

  if (!wm.autoConnect("SENTRI_SmartHome")) {
    ESP.restart();
  }

  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
}

void loop() {
  ArduinoCloud.update();

  if (ArduinoCloud.connected() && !firstSyncDone) {
    syncHardware();
    firstSyncDone = true;
  }

  if (firstSyncDone) {
    checkButton(WALL_SWITCH_PIN, lastWallState, "Wall");
    checkButton(Sleep_switch, lastSleepState, "Sleep");
    checkButton(Work_switch, lastWorkState, "Work");
    checkButton(All_switch, lastAllState, "All"); // تحديث الاسم هنا
  }
}

void checkButton(int pin, bool &lastState, String type) {
  bool currentReading = digitalRead(pin);
  if (currentReading != lastState) {
    delay(50);
    if (digitalRead(pin) == currentReading) {
      if (type == "Wall") { led1 = !led1; } 
      else if (type == "Sleep") { activateSleepMode(); } 
      else if (type == "Work") { activateWorkMode(); } 
      else if (type == "All") { activateAllMode(); } // استدعاء وضع الكل
      
      syncHardware();
      lastState = currentReading;
    }
  }
}

// --- Scenarios (Modes) | السيناريوهات المعدلة ---

void activateSleepMode() {
  // وضع النوم: طفي كل الأضواء، شغل قابس 1 وطفي قابس 2
  // Sleep: Lights OFF, Socket 1 ON, Socket 2 OFF
  led1 = false;
  led2 = false;
  // led3 = false; 
  switch1 = true;  // القابس الأول شغال
  switch2 = false; // القابس الثاني طافي
  Light.setSwitch(false); // شريط اللد طافي
}

void activateWorkMode() {
  // وضع العمل: شغل كل الأباريز، اللد 35%، وشغل ضوء واحد (ضوء غرفة العمل)
  // Work: All Sockets ON, LED Strip 35%, One light ON
  switch1 = true;
  switch2 = true;
  Light.setBrightness(35); // شدة السطوع 35%
  Light.setSwitch(true);
  led1 = true;  // ضوء غرفة العمل
  led2 = false;
}

void activateAllMode() {
  // وضع الكل: تشغيل كل شيء في النظام
  // All Mode: Turn everything ON
  led1 = true;
  led2 = true;
  switch1 = true;
  switch2 = true;
  Light.setBrightness(100);
  Light.setSwitch(true);
}

void syncHardware() {
  onLed1Change();
  onLed2Change();
  onSwitch1Change();
  onSwitch2Change();
  onLightChange();
}

// --- Cloud Callbacks ---

void onLed1Change() { digitalWrite(LED_1, led1 ? LOW : HIGH); }
void onLed2Change() { digitalWrite(Led_2, led2 ? LOW : HIGH); }
void onSwitch1Change() { digitalWrite(POWER_1, switch1 ? LOW : HIGH); }

void onSwitch2Change() {
  if (switch2) {
    pinMode(POWER_2, OUTPUT);
    digitalWrite(POWER_2, LOW); 
  } else {
    pinMode(POWER_2, INPUT_PULLUP);
  }
}

void onLightChange() {
  if (Light.getSwitch()) {
    int pwmValue = map(Light.getBrightness(), 0, 100, 0, 255);
    ledcWrite(channel, pwmValue);
  } else {
    ledcWrite(channel, 0);
  }
}